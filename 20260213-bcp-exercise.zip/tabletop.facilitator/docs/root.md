# Root Cause Disclosure

## Root Cause (Malicious Variant): 
An attacker compromised a management account and administratively shut down the specific ports used for the Cluster Control Link (ports FPC1-HA0, etc.), attempting to disrupt logs before exfiltrating data.