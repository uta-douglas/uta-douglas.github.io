# Tabletop Exercise

## Introduction

Participants will be given the [URL to the exercise](/tabletop/). After the initial introductions, they will be given [Injection](injections.md) #1 to kick off the event.

## Notes

* Do not specifically mention Kuali during prep as we are trying to see if it is referenced spontaneously by the participants.