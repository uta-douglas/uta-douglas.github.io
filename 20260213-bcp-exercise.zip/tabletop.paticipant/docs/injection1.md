# Injection #1

*Time: 2026-02-13 1:00 PM*

## Service Desk Tickets
Service Desk reports "random" login failures. Some users connect fine (their traffic stayed symmetric), others fail.

* [INC-88421](INC-88421.md) - URGENT: Intermittent Access to Research Portal and Grant Submission Site
* [INC-88422](INC-88422.md) - Issues logging into PeopleSoft / Finance Systems
* [INC-88423](INC-88423.md) - Canvas login not working - getting "Site Cannot Be Reached"