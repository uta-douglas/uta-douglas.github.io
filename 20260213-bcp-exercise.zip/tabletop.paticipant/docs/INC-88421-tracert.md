# INC-88421: Trace Analysis: Dr. Aris Thorne

**Target:** sso.uta.edu (Simulated Cloud/Azure Endpoint)  
**Status:** Request timed out at the edge. 

--- 

`Tracing route to sso.uta.edu [23.102.165.255]
over a maximum of 30 hops:`  
  
`  1    <1 ms    <1 ms    <1 ms  10.15.20.1 (ERB-Floor-Gateway)`  
`  2    <1 ms    <1 ms    <1 ms  172.16.1.5 (Core-Aggregation-Switch)`  
`  3     1 ms     1 ms     1 ms  192.168.100.2 (ERB-MX960-Router)`  
`  4     * * * Request timed out.`  
`  5     * * * Request timed out.`  
`  6     * * * Request timed out.`  
`  7   ^C  `
 
  ---
  
  